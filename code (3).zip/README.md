# MindFlow - AI-Powered Mental Wellness Study Companion

## Overview
MindFlow combines AI-powered scheduling with mental wellness principles to help students study smarter, not harder.

## Features
- **Brain Dump**: Express everything you need to study without organizing
- **AI-Powered Planning**: Uses Claude AI to generate personalized study schedules
- **Energy Mapping**: Schedules tasks based on your peak energy times (morning/afternoon/night)
- **Emotion Tracking**: Adapts your study plan based on your current emotional state
- **Progress Celebration**: Tracks completed tasks and motivates continued progress
- **Personalized Wellness Tips**: Provides context-aware study and mental health tips

## Setup

### Prerequisites
- Node.js 16+
- npm or yarn
- Anthropic API key

### Installation

1. Install dependencies:
\`\`\`bash
npm install
\`\`\`

2. Set up environment variables:
\`\`\`bash
export ANTHROPIC_API_KEY="your-api-key-here"
\`\`\`

3. Start the backend server:
\`\`\`bash
npm start
\`\`\`

The server will run on `http://localhost:3001`

4. Open the frontend:
Open `index.html` in your browser or serve it via a static file server

## API Endpoints

### POST /api/session/start
Creates a new user session
**Response**: `{ sessionId, message }`

### POST /api/study-plan/generate
Generates an AI-powered study plan
**Body**: 
\`\`\`json
{
  "sessionId": "...",
  "formData": {
    "tasks": "...",
    "deadline": "...",
    "knowledge": "beginner|intermediate|advanced",
    "hours": 4,
    "challenges": ["..."],
    "energyTime": "morning|afternoon|night|unsure"
  }
}
\`\`\`

### POST /api/study-plan/adapt-emotion
Adapts the study plan based on emotional state
**Body**: `{ "sessionId": "...", "emotion": "happy|normal|anxious|tired|frustrated" }`

### POST /api/task/complete
Records a completed task
**Body**: `{ "sessionId": "...", "taskId": 1 }`

### GET /api/session/:sessionId
Retrieves session data

### POST /api/study-plan/regenerate
Regenerates the study plan with the same input parameters

### GET /api/wellness-tips
Retrieves wellness tips

## Data Persistence
- User sessions are stored in `data/sessions.json`
- User data is stored in `data/users.json`
- All data is persisted to the filesystem

## How It Works

1. **User Submits Brain Dump**: Student enters tasks and personal info
2. **AI Analysis**: Claude AI analyzes the input and generates a personalized study plan
3. **Plan Optimization**: Tasks are ordered based on energy levels and deadline
4. **Emotion Tracking**: Student can update their emotion, triggering plan adaptations
5. **Progress Tracking**: Completed tasks are recorded and progress is visualized
6. **Plan Regeneration**: If needed, users can regenerate their plan with new adaptations

## Study Plan Generation

The AI generates plans that include:
- Task decomposition (breaking large topics into smaller steps)
- Strategic break placement (following Pomodoro-style intervals)
- Difficulty progression (adapting to the student's knowledge level)
- Personalized study tips for each task
- Challenge accommodations (anxiety reduction, procrastination strategies, etc.)
- Energy-optimized scheduling

## Emotion Adaptation

Based on the student's emotional state, MindFlow:
- **Happy/Focused**: Keeps challenging tasks, adds celebration milestones
- **Normal**: Maintains balanced pace
- **Anxious**: Reduces difficulty, increases breaks, adds calming activities
- **Tired**: Switches to passive learning, increases rest time
- **Frustrated**: Starts with easy wins to build momentum
